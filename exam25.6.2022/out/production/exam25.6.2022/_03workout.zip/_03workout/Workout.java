package _03workout;

import java.util.ArrayList;
import java.util.List;

public class Workout {
    private List<Exercise> exercises = new ArrayList<>();
    private String type;
    private int exerciseCount;

    public Workout(String type, int exerciseCount) {
        this.type = type;
        this.exerciseCount = exerciseCount;
    }

    public void addExercise(Exercise exercise) {
        if (exercises.size() < exerciseCount) {
            exercises.add(exercise);
        }
    }
    public boolean removeExercise(String name,String muscle) {
        for (Exercise ex:exercises) {
            if (ex.getName().equals(name)&&ex.getMuscle().equals(muscle)){
                exercises.remove(ex);
                return true;
            }
        }
        return false;
    }
    public Exercise getExercise(String name,String muscle){
        for (Exercise ex:exercises) {
            if (ex.getName().equals(name)&&ex.getMuscle().equals(muscle)){
                return ex;
            }
        }
        return null;
    }
    public Exercise getMostBurnedCaloriesExercise(){
        int caloriesBurned = 0;
        Exercise bestEx=null;
        if (exercises.size()>0){
            for (Exercise ex:exercises){
                if (ex.getBurnedCalories()>caloriesBurned){
                    bestEx=ex;
                }
            }
        }
        return bestEx;
    }
    public int getExerciseCount(){
        return exercises.size();
    }
    public String getStatistics(){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Workout type: ").append(type);
        for (Exercise ex:exercises) {
            stringBuilder.append("\n").append(ex);
        }
        return stringBuilder.toString();
    }
}

